// import chai 
const chai = require('chai')
const expect = chai.expect

describe("First test collection",()=>{
    it("Should text values",()=>{
        let expectedValue = Math.abs(-10)
        let actualValue = 10
        expect(actualValue).to.be.equal(expectedValue)
    })
})